import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {

        Quiz quiz = createQuiz();


        quiz.shuffleQuestions();


        UserInteraction userInteraction = new UserInteraction();
        Scoring scoring = new Scoring();


        List<Question> questions = quiz.getQuestions();
        int[] userResponses = new int[questions.size()];

        for (int i = 0; i < questions.size(); i++) {
            final int index = i;
            final Question question = questions.get(i);
            userInteraction.displayQuestion(question);

            ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor();


            timer.schedule(() -> {
                System.out.println("Time's up!");
                if (userResponses[index] == 0) {
                    System.out.println("Correct answer: " + (question.getCorrectOptionIndex() + 1) + ". " + question.getOptions()[question.getCorrectOptionIndex()]);
                }
                userResponses[index] = -1;
            }, 30, TimeUnit.SECONDS);

            userResponses[index] = userInteraction.getUserResponse(question.getOptions().length);


            timer.shutdownNow();

            if (userResponses[index] == question.getCorrectOptionIndex() + 1) {
                System.out.println("Correct!");
            } else {
                System.out.println("Incorrect! The correct answer is: " + (question.getCorrectOptionIndex() + 1) + ". " + question.getOptions()[question.getCorrectOptionIndex()]);
            }
        }

        int score = scoring.calculateScore(questions, userResponses);
        System.out.println("Your score: " + score + "/" + questions.size());
    }


    private static Quiz createQuiz() {
        List<Question> questionList = new ArrayList<>();

        questionList.add(new Question("What is the powerhouse of the cell?", new String[]
                {"Mitochondria", "Nucleus", "Ribosome"}, 0));

        questionList.add(new Question("Which planet is known as the Red Planet?", new String[]
                {"Mars", "Jupiter", "Venus"}, 0));

        questionList.add(new Question("What is the capital of France?", new String[]
                {"Paris", "London", "Berlin"}, 0));

        questionList.add(new Question("What is the largest ocean on Earth?", new String[]
                {"Pacific Ocean", "Atlantic Ocean", "Indian Ocean"}, 0));

        questionList.add(new Question("What is the chemical symbol for water?", new String[]
                {"H2O", "CO2", "N2"}, 0));

        questionList.add(new Question("What is the largest country in the world by land area", new String[]
                {"Russia", "Canada", "China"}, 0));

        questionList.add(new Question("What is the pH value of the human body?", new String[]
                {"9.2 to 9.8", "7.0 to 7.8", "5.4 to 5.6"}, 0));

        questionList.add(new Question(" Which of the given cities is located on the bank of river Ganga?", new String[]
                {"Patna", "Bhopal", "Mathura"}, 0));

        questionList.add(new Question(" Which of the given vitamin is a water-soluble vitamin?", new String[]
                {"Vitamin A", "Vitamin B", "Vitamin C"}, 0));

        questionList.add(new Question(" Which of the given vitamins is responsible for blood clotting?", new String[]
                {"Vitamin A", "Vitamin B", "Vitamin K"}, 0));

        Quiz quiz = new Quiz(questionList);
        return quiz;
    }
}
