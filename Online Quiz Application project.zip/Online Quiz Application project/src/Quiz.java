import java.util.Collections;
import java.util.List;

public class Quiz {
    private List<Question> questions;

    public Quiz(List<Question> questions) {
        this.questions = questions;
    }


    public void shuffleQuestions() {
        Collections.shuffle(questions);
    }

    public List<Question> getQuestions() {
        return questions;
    }
}
