import java.util.List;

public class Scoring {
    public int calculateScore(List<Question> questions, int[] userResponses) {
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (userResponses[i] == questions.get(i).getCorrectOptionIndex() + 1) {
                score++;
            }
        }
        return score;
    }
}
