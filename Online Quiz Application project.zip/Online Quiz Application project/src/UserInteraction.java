import java.util.Scanner;

public class UserInteraction {
    private final Scanner scanner;

    public UserInteraction() {
        scanner = new Scanner(System.in);
    }

    public int getUserResponse(int numOfOptions) {
        int response;
        while (true) {
            try {
                response = scanner.nextInt();
                if (response < 1 || response > numOfOptions) {
                    throw new IllegalArgumentException();
                }
                break;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number between 1 and " + numOfOptions + ".");
                scanner.next(); // consume invalid input
            }
        }
        return response;
    }

    public void displayQuestion(Question question) {
        System.out.println(question.getQuestionText());
        String[] options = question.getOptions();
        for (int i = 0; i < options.length; i++) {
            System.out.println((i + 1) + ". " + options[i]);
        }
        System.out.print("Your answer: ");
    }
}
